﻿namespace Contracts;

public interface IFacultyAnalysisRepository
{
}
