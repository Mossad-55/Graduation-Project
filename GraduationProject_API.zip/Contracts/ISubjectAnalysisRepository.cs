﻿namespace Contracts;

public interface ISubjectAnalysisRepository
{
}
