﻿namespace Contracts;
public interface IDepartmentAnalysisRepository 
{
}
