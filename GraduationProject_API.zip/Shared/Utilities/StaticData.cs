﻿namespace Shared.Utilities;

public static class StaticData
{
    public static string UniversityAdminRole = "University Admin";
    public static string FacultyAdminRole = "Faculty Admin";
    public static string DepartmentAdminRole = "Department Admin";
    public static string ProfessorRole = "Professor";
    public static string StudentRole = "Student";
    
}
