﻿namespace Shared.DataTranferObjects;

public record FacultyDto(Guid Id, string Name, string Description, double Rate);
