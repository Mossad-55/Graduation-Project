﻿namespace Shared.DataTranferObjects;

public record DepartmentDto(Guid Id, string Name, string Description, double Rate);
