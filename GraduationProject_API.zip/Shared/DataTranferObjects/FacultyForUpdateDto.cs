﻿namespace Shared.DataTranferObjects;

public record FacultyForUpdateDto(string Name, string Description);
