﻿namespace Shared.DataTranferObjects;

public record UniversityDto(Guid Id, string Name, string Description, double Rate);
