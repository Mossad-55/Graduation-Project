﻿namespace Shared.DataTranferObjects;

public record FacultyForCreationDto(string Name, string Description);
