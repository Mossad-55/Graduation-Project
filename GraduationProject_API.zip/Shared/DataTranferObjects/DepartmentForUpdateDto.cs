﻿namespace Shared.DataTranferObjects;

public record DepartmentForUpdateDto(string Name, string Description);
