﻿namespace Shared.DataTranferObjects;

public record UniversityForUpdateDto(string Name, string Description);
