﻿namespace Shared.DataTranferObjects;

public record UserForCreationDto(string FirstName, string LastName, string Email, string PhoneNumber, string Password);
