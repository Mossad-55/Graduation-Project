﻿namespace Shared.DataTranferObjects;

public record QuestionnaireForUpdateDto(string Title, DateTime CreatedAt, DateTime EndDate);
