﻿namespace Shared.DataTranferObjects;

public record DepartmentForCreateDto(string Name, string Description);
