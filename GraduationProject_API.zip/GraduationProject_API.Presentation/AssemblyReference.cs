﻿namespace GraduationProject_API.Presentation;

public static class AssemblyReference
{

}
